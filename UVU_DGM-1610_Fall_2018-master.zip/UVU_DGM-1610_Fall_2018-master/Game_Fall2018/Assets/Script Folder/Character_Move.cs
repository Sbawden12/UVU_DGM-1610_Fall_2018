﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character_Move : MonoBehaviour {

	public int MoveSpeed;
	private float JumpHeight;

	// Use this for initialization
	void Start () 
	{
		print("Hello World!");
	}
	
	// Update is called once per frame
	void Update () 
	{
		
	}
}
